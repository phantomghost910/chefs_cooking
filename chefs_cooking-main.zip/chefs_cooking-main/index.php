<?php
require __DIR__ . '/table_call_on.php';
require __DIR__ . '/views/index.view.php';
