// Zonder JavaScript blijven alle stappen gewoon zichtbaar.
const stappen = document.querySelectorAll('.kookstap');
const vorige = document.getElementById('vorige');
const volgende = document.getElementById('volgende');
const alles = document.getElementById('alleStappen');
let huidigeStap = 0;
let toonAlles = false;
document.getElementById('kookknoppen').hidden = false;
function toonStap(verplaatsFocus) {
    stappen.forEach((stap, nummer) => { stap.hidden = !toonAlles && nummer !== huidigeStap; });
    vorige.disabled = toonAlles || huidigeStap === 0;
    volgende.disabled = toonAlles || huidigeStap === stappen.length - 1;
    document.getElementById('stapstand').textContent = toonAlles ? 'Alle stappen' : 'Stap ' + (huidigeStap + 1) + ' van ' + stappen.length;
    alles.textContent = toonAlles ? 'Stap voor stap' : 'Toon alle stappen';
    if (verplaatsFocus) stappen[huidigeStap].querySelector('h3').focus();
}
vorige.addEventListener('click', () => { if (huidigeStap > 0) huidigeStap--; toonStap(true); });
volgende.addEventListener('click', () => { if (huidigeStap < stappen.length - 1) huidigeStap++; toonStap(true); });
alles.addEventListener('click', () => { toonAlles = !toonAlles; toonStap(false); });
toonStap(false);
