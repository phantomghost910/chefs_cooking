<?php bovenkant('Recepten'); ?>
<div class="topnav"><input type="search" id="searchInput" placeholder="Zoek een recept..." aria-label="Zoek een recept"></div>
<div class="filters">
<select id="categoryFilter" aria-label="Categorie"><option value="">Alle categorieën</option><?php foreach (['pasta','vlees','vegetarisch','vis','rijst','overig'] as $categorie): ?><option value="<?= $categorie ?>"><?= ucfirst($categorie) ?></option><?php endforeach; ?></select>
<select id="timeFilter" aria-label="Bereidingstijd"><option value="">Alle bereidingstijden</option><?php foreach ([15,20,30,45] as $aantal): ?><option value="<?= $aantal ?>">Maximaal <?= $aantal ?> minuten</option><?php endforeach; ?></select>
<select id="priceFilter" aria-label="Prijs"><option value="">Alle prijzen</option><?php foreach ([2,3,4] as $aantal): ?><option value="<?= $aantal ?>">Maximaal €<?= $aantal ?></option><?php endforeach; ?></select>
<button id="resetFilters" type="button">Filters wissen</button></div>
<p id="resultCount" aria-live="polite"></p><p id="noResults" style="display:none">Geen recepten gevonden.</p>
<main class="container">
<?php foreach ($resultaten_recepten as $recept): ?>
<article class="box" data-category="<?= veilig($recept['categorie']) ?>" data-time="<?= minuten($recept['Tijd']) ?>" data-price="<?= veilig($recept['Prijs']) ?>">
<?= fotoHtml($recept['foto'], $recept['Naam']) ?>
<h1><?= veilig($recept['Naam']) ?></h1><h2>Prijs: €<?= number_format((float)$recept['Prijs'], 2, ',', '.') ?></h2><h3>Bereidingstijd: <?= minuten($recept['Tijd']) ?> minuten</h3><p><?= veilig($recept['info']) ?></p>
<a class="recipeButton" href="recept.php?id=<?= (int)$recept['ID'] ?>">Bekijk recept →</a>
</article>
<?php endforeach; ?>
</main><script src="views/script/script.js"></script></body></html>
