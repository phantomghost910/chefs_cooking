<?php
require_once __DIR__ . '/start.php';
$resultaten_recepten = $conn->query('SELECT * FROM recepten ORDER BY ID DESC')->fetchAll();
$aantal_recepten = count($resultaten_recepten);
