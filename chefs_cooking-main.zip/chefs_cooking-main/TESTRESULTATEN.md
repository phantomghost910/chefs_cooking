# Uitgevoerde controles

## Geslaagd

Alle acht PHP-bestanden zijn gecontroleerd op syntaxfouten met PHP in WebAssembly. Er zijn geen syntaxfouten gevonden. De databaseverbinding is byte voor byte gelijk aan die in het aangeleverde ZIP-bestand.

Er zijn daarnaast 46 controles uitgevoerd met de echte PHP-pagina’s en JavaScript-bestanden. Daarvoor is een aparte kopie gebruikt met een SQLite-testdatabase en een kleine PDO-testadapter. Die adapter vervangt alleen de MySQL-verbindingsinstelling en de MySQL-specifieke opdrachten SET NAMES en FOR UPDATE. De adapter en testdatabase zitten niet in dit project.

Onder andere gecontroleerd:

- Recept toevoegen zonder foto en tonen op homepage/detailpagina.
- Recept toevoegen met een echte PNG-upload.
- Tekst met HTML veilig tonen.
- Ingrediënten en stappen toevoegen en bewerken, met koppeling aan een recept.
- Foto behouden bij bewerken zonder nieuwe upload.
- Mislukte upload laat de bestaande foto en databasegegevens intact.
- Foto vervangen, oud bestand opruimen en foto verwijderen.
- Lege naam, ongeldige tijd, ongeldige prijs en onbekend recept weigeren.
- Nepafbeelding, te grote upload en ongeldig formuliertoken weigeren.
- Ingrediënten en stappen afzonderlijk verwijderen.
- Een fout halverwege verwijderen draait eerdere verwijderingen terug.
- Recept verwijderen met gekoppelde onderdelen; een ander recept blijft bestaan.
- Verwijderd recept geeft een 404-pagina.
- Na succesvol opslaan volgt een redirect.
- Zoeken, categorie-, tijd- en prijsfilter, lege resultaten en resetknop.
- Vorige/volgende stap, eerste/laatste stap en alle stappen tonen.

De JavaScript-controles gebruikten de door PHP gemaakte HTML in een nagebootste browseromgeving (JSDOM).

## Nog niet op jouw server getest

- De verbinding met jouw echte MySQL-server en het uitvoeren van de SQL-aanpassing.
- MySQL-relaties, toegangsrechten, gelijktijdige bewerkingen en serverconfiguratie.
- De schrijf- en uploadrechten van jouw hosting en de Apache/Nginx-regels.
- Het uiterlijk in een echte browser op desktop en telefoon.
- De gehele handmatige route op jouw hosting, inclusief Annuleren, browserbevestiging en verversen.

De testdatabase vervangt geen eindcontrole op jouw eigen MySQL-server. Gebruik de lijst in START_HIER.md na installatie.
