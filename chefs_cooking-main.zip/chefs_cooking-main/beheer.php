<?php
session_start();
require __DIR__ . '/start.php';
if (empty($_SESSION['crud_token'])) $_SESSION['crud_token'] = bin2hex(random_bytes(32));
$tabellen = ['recepten', 'recepten_ingredienten', 'recepten_stappen'];
$tabel = tekst($_GET, 'tabel') ?: 'recepten';
if (!in_array($tabel, $tabellen, true)) { http_response_code(400); exit('Ongeldige tabel.'); }
$actie = tekst($_GET, 'actie') ?: 'overzicht';
$id = tekst($_GET, 'id');
$fout = '';
$record = [];
$nieuwPad = null;
$oudPad = '';
$categorieen = ['pasta','vlees','vegetarisch','vis','rijst','overig'];
$labels = ['recepten' => 'Recepten', 'recepten_ingredienten' => 'Ingrediënten', 'recepten_stappen' => 'Bereidingsstappen'];

// Alleen deze vaste velden worden opgeslagen. Geen veldnamen uit het formulier in SQL.
if ($tabel === 'recepten') {
    $velden = ['Naam','Tijd','Prijs','foto','info','categorie'];
} elseif ($tabel === 'recepten_ingredienten') {
    $velden = ['Naam','recept_id'];
} else {
    $velden = ['recept_id','Naam_title','Tijden','Prijs','beschrijving_stap'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actie = tekst($_POST, 'actie');
    $id = tekst($_POST, 'id');
    foreach ($velden as $veld) $record[$veld] = tekst($_POST, $veld);
    try {
        if (!hash_equals($_SESSION['crud_token'], tekst($_POST, 'token'))) throw new RuntimeException('Dit formulier is verlopen. Vernieuw de pagina en probeer opnieuw.');
        if (!in_array($actie, ['toevoegen','bewerken','verwijderen'], true)) throw new RuntimeException('Ongeldige actie.');
        if ($actie !== 'toevoegen' && !getal($id, 1, 2147483647)) throw new RuntimeException('Ongeldig nummer.');
        $conn->beginTransaction();
        if ($actie !== 'toevoegen') {
            $query = $conn->prepare('SELECT * FROM ' . $tabel . ' WHERE ID = ? FOR UPDATE');
            $query->execute([$id]);
            $bestaand = $query->fetch();
            if (!$bestaand) throw new RuntimeException('Dit onderdeel bestaat niet meer.');
            $oudPad = $bestaand['foto'] ?? '';
        }
        if ($actie === 'verwijderen') {
            // Eerst de gekoppelde onderdelen verwijderen, daarna het recept zelf.
            if ($tabel === 'recepten') {
                $query = $conn->prepare('DELETE FROM recepten_ingredienten WHERE recept_id = ?'); $query->execute([$id]);
                $query = $conn->prepare('DELETE FROM recepten_stappen WHERE recept_id = ?'); $query->execute([$id]);
            }
            $query = $conn->prepare('DELETE FROM ' . $tabel . ' WHERE ID = ?'); $query->execute([$id]);
        } else {
            if ($tabel === 'recepten') {
                if ($record['Naam'] === '' || lengte($record['Naam']) > 60) throw new RuntimeException('Vul een receptnaam in van maximaal 60 tekens.');
                if ($record['info'] === '' || lengte($record['info']) > 1000) throw new RuntimeException('Vul een beschrijving in van maximaal 1000 tekens.');
                if (!getal($record['Tijd'], 1, 50339)) throw new RuntimeException('Vul een bereidingstijd in van 1 tot en met 50339 minuten.');
                $prijs = str_replace(',', '.', $record['Prijs']);
                if (!preg_match('/^\d{1,8}(\.\d{1,2})?$/', $prijs)) throw new RuntimeException('Vul een geldige prijs in, bijvoorbeeld 2,50.');
                if (!in_array($record['categorie'], $categorieen, true)) throw new RuntimeException('Kies een categorie.');
                $record['foto'] = $oudPad;
                if (tekst($_POST, 'foto_verwijderen') === 'ja') $record['foto'] = '';
                $nieuwPad = uploadFoto();
                if ($nieuwPad !== null) $record['foto'] = $nieuwPad;
                $waarden = [$record['Naam'], tijd($record['Tijd']), $prijs, $record['foto'], $record['info'], $record['categorie']];
            } else {
                if (!getal($record['recept_id'], 1, 2147483647)) throw new RuntimeException('Kies een geldig recept.');
                $query = $conn->prepare('SELECT ID FROM recepten WHERE ID = ? FOR UPDATE'); $query->execute([$record['recept_id']]);
                if (!$query->fetch()) throw new RuntimeException('Het gekozen recept bestaat niet meer.');
                if ($tabel === 'recepten_ingredienten') {
                    if ($record['Naam'] === '' || lengte($record['Naam']) > 1000) throw new RuntimeException('Vul een ingrediënt in van maximaal 1000 tekens.');
                    $waarden = [$record['Naam'], $record['recept_id']];
                } else {
                    if ($record['Naam_title'] === '' || lengte($record['Naam_title']) > 40) throw new RuntimeException('Vul een staptitel in van maximaal 40 tekens.');
                    if ($record['beschrijving_stap'] === '' || lengte($record['beschrijving_stap']) > 6000) throw new RuntimeException('Vul de uitleg in, maximaal 6000 tekens.');
                    if (!getal($record['Tijden'], 0, 2147483647)) throw new RuntimeException('Vul een heel aantal minuten in, vanaf 0.');
                    if (!getal($record['Prijs'], 0, 2147483647)) throw new RuntimeException('De prijs van een stap moet een heel getal zijn, vanaf 0.');
                    $waarden = [$record['recept_id'], $record['Naam_title'], $record['Tijden'], $record['Prijs'], $record['beschrijving_stap']];
                }
            }
            if ($actie === 'toevoegen') {
                $plaatsen = implode(', ', array_fill(0, count($velden), '?'));
                $query = $conn->prepare('INSERT INTO ' . $tabel . ' (`' . implode('`, `', $velden) . '`) VALUES (' . $plaatsen . ')');
            } else {
                $sets = [];
                foreach ($velden as $veld) $sets[] = '`' . $veld . '` = ?';
                $waarden[] = $id;
                $query = $conn->prepare('UPDATE ' . $tabel . ' SET ' . implode(', ', $sets) . ' WHERE ID = ?');
            }
            $query->execute($waarden);
        }
        $conn->commit();
        // Foto pas opruimen nadat de databasewijziging echt is opgeslagen.
        try { verwijderLosseFoto($conn, $oudPad); } catch (Throwable $e) { error_log('Opruimen van een oude receptfoto is uitgesteld.'); }
        $_SESSION['melding'] = $actie === 'verwijderen' ? 'Verwijderd.' : 'Opgeslagen. Je wijziging is direct zichtbaar op de website.';
        $_SESSION['crud_token'] = bin2hex(random_bytes(32));
        header('Location: beheer.php?tabel=' . urlencode($tabel)); exit;
    } catch (Throwable $e) {
        if ($conn->inTransaction()) $conn->rollBack();
        if ($nieuwPad !== null) {
            try { verwijderLosseFoto($conn, $nieuwPad); } catch (Throwable $opruimFout) { error_log('Opruimen van een nieuwe receptfoto is uitgesteld.'); }
        }
        $record['foto'] = $oudPad;
        $fout = $e instanceof RuntimeException && !($e instanceof PDOException) ? $e->getMessage() : 'Opslaan lukt niet. Controleer de database-instellingen en probeer opnieuw.';
    }
} elseif ($actie === 'bewerken') {
    $query = $conn->prepare('SELECT * FROM ' . $tabel . ' WHERE ID = ?');
    $query->execute([getal($id, 1, 2147483647) ? $id : 0]);
    $record = $query->fetch();
    if (!$record) { http_response_code(404); bovenkant('Niet gevonden'); exit('<main class="beheer"><p>Dit onderdeel bestaat niet.</p><a href="beheer.php">Terug naar beheer</a></main></body></html>'); }
    if ($tabel === 'recepten') $record['Tijd'] = minuten($record['Tijd']);
}
$recepten = $conn->query('SELECT ID, Naam FROM recepten ORDER BY Naam')->fetchAll();
if ($tabel === 'recepten') {
    $rijen = $conn->query('SELECT * FROM recepten ORDER BY ID DESC')->fetchAll();
} else {
    $rijen = $conn->query('SELECT onderdeel.*, recepten.Naam AS receptnaam FROM ' . $tabel . ' AS onderdeel LEFT JOIN recepten ON recepten.ID = onderdeel.recept_id ORDER BY onderdeel.recept_id, onderdeel.ID')->fetchAll();
}
bovenkant('Beheer');
?>
<main class="beheer">
<h2><?= veilig($labels[$tabel]) ?> beheren</h2>
<nav class="menu"><?php foreach ($labels as $naam => $label): ?><a href="beheer.php?tabel=<?= $naam ?>"><?= $label ?></a><?php endforeach; ?></nav>
<p>Voeg eerst een recept toe. Kies daarna bij Ingrediënten en Bereidingsstappen het recept waarvoor je iets wilt invullen.</p>
<?php if (isset($_SESSION['melding'])): ?><p class="succes" role="status"><?= veilig($_SESSION['melding']) ?></p><?php unset($_SESSION['melding']); endif; ?>
<?php if ($fout): ?><p class="fout" role="alert"><?= veilig($fout) ?><?php if ($tabel === 'recepten'): ?> Kies de foto opnieuw als je er een wilde uploaden.<?php endif; ?></p><?php endif; ?>
<?php if ($actie === 'toevoegen' || $actie === 'bewerken'): ?>
<h3><?= $actie === 'toevoegen' ? 'Toevoegen' : 'Bewerken' ?></h3>
<form method="post" enctype="multipart/form-data" action="beheer.php?tabel=<?= $tabel ?>">
<input type="hidden" name="token" value="<?= veilig($_SESSION['crud_token']) ?>"><input type="hidden" name="actie" value="<?= veilig($actie) ?>"><input type="hidden" name="id" value="<?= veilig($id) ?>">
<?php if ($tabel !== 'recepten'): ?>
<label>Bij welk recept hoort dit?<select name="recept_id" required><option value="">Kies een recept</option><?php foreach ($recepten as $recept): ?><option value="<?= (int)$recept['ID'] ?>" <?= (string)($record['recept_id'] ?? '') === (string)$recept['ID'] ? 'selected' : '' ?>><?= veilig($recept['Naam']) ?></option><?php endforeach; ?></select></label>
<?php if (!$recepten): ?><p>Voeg eerst een recept toe.</p><?php endif; ?>
<?php endif; ?>
<?php if ($tabel === 'recepten'): ?>
<label>Naam<input name="Naam" maxlength="60" required value="<?= veilig($record['Naam'] ?? '') ?>"></label>
<label>Bereidingstijd in minuten<input type="number" name="Tijd" min="1" max="50339" required value="<?= veilig($record['Tijd'] ?? '') ?>"></label>
<label>Prijs in euro<input name="Prijs" inputmode="decimal" placeholder="2,50" required value="<?= veilig($record['Prijs'] ?? '') ?>"></label>
<label>Categorie<select name="categorie" required><?php foreach ($categorieen as $categorie): ?><option value="<?= $categorie ?>" <?= ($record['categorie'] ?? 'overig') === $categorie ? 'selected' : '' ?>><?= ucfirst($categorie) ?></option><?php endforeach; ?></select></label>
<label>Korte beschrijving<textarea name="info" maxlength="1000" required><?= veilig($record['info'] ?? '') ?></textarea></label>
<div class="voorbeeld"><?= fotoHtml($record['foto'] ?? '', $record['Naam'] ?? 'Recept') ?></div>
<label>Foto (JPG, PNG of WebP, maximaal 5 MB)<input type="file" name="foto" accept="image/jpeg,image/png,image/webp"></label>
<p>Geen nieuwe foto kiezen? Dan blijft de bestaande foto staan.</p>
<label class="checkbox"><input type="checkbox" name="foto_verwijderen" value="ja" <?= tekst($_POST, 'foto_verwijderen') === 'ja' ? 'checked' : '' ?>> Bestaande foto verwijderen</label>
<?php elseif ($tabel === 'recepten_ingredienten'): ?>
<label>Ingrediënt en hoeveelheid<input name="Naam" maxlength="1000" placeholder="Bijvoorbeeld: 200 gram pasta" required value="<?= veilig($record['Naam'] ?? '') ?>"></label>
<?php else: ?>
<p>Stappen verschijnen in de volgorde waarin je ze toevoegt. Vul ze dus in de juiste kookvolgorde in.</p>
<label>Korte titel<input name="Naam_title" maxlength="40" required placeholder="Bijvoorbeeld: Kook de pasta" value="<?= veilig($record['Naam_title'] ?? '') ?>"></label>
<label>Tijd van deze stap in minuten<input type="number" name="Tijden" min="0" max="2147483647" required value="<?= veilig($record['Tijden'] ?? '0') ?>"></label>
<label>Prijs van deze stap in hele euro’s<input type="number" name="Prijs" min="0" max="2147483647" required value="<?= veilig($record['Prijs'] ?? '0') ?>"></label>
<p>Dit bestaande databaseveld accepteert alleen hele euro’s. Laat 0 staan als een aparte stapprijs niet nodig is. De receptprijs mag wel centen bevatten.</p>
<label>Leg uit wat je moet doen<textarea name="beschrijving_stap" maxlength="6000" required placeholder="Breng een pan water aan de kook. Voeg de pasta toe en kook volgens de verpakking."><?= veilig($record['beschrijving_stap'] ?? '') ?></textarea></label>
<?php endif; ?>
<button type="submit">Opslaan</button><a class="knop" href="beheer.php?tabel=<?= $tabel ?>">Annuleren</a>
</form>
<?php else: ?>
<a class="knop" href="beheer.php?tabel=<?= $tabel ?>&actie=toevoegen">+ Toevoegen</a>
<div class="tabel"><table><thead><tr><th>Naam</th><th>Gegevens</th><th>Acties</th></tr></thead><tbody>
<?php foreach ($rijen as $rij): ?>
<tr><td><?= veilig($rij['Naam'] ?? $rij['Naam_title']) ?>
<?php if ($tabel === 'recepten'): ?><div class="kleine-foto"><?= fotoHtml($rij['foto'], $rij['Naam']) ?></div><?php endif; ?></td>
<td><?php if ($tabel === 'recepten'): ?><?= minuten($rij['Tijd']) ?> min · €<?= number_format((float)$rij['Prijs'],2,',','.') ?><br><?= veilig($rij['categorie']) ?>
<?php else: ?>Recept: <?= veilig($rij['receptnaam'] ?? 'Recept ontbreekt') ?><?php if ($tabel === 'recepten_stappen'): ?><p><?= nl2br(veilig($rij['beschrijving_stap'])) ?></p><p><?= (int)$rij['Tijden'] ?> minuten · €<?= (int)$rij['Prijs'] ?></p><?php endif; ?><?php endif; ?></td>
<td><a href="recept.php?id=<?= (int)($tabel === 'recepten' ? $rij['ID'] : $rij['recept_id']) ?>">Bekijken</a> · <a href="beheer.php?tabel=<?= $tabel ?>&actie=bewerken&id=<?= (int)$rij['ID'] ?>">Bewerken</a>
<form method="post" action="beheer.php?tabel=<?= $tabel ?>" onsubmit="return confirm('Weet je zeker dat je dit wilt verwijderen? Bij een recept worden ook de ingrediënten en stappen verwijderd.');">
<input type="hidden" name="token" value="<?= veilig($_SESSION['crud_token']) ?>"><input type="hidden" name="actie" value="verwijderen"><input type="hidden" name="id" value="<?= (int)$rij['ID'] ?>"><button class="verwijderen" type="submit">Verwijderen</button></form></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php if (!$rijen): ?><p>Er is nog niets toegevoegd.</p><?php endif; ?>
<?php endif; ?></main></body></html>
