-- Maak eerst een back-up. Voer dit één keer uit in je bestaande database.
-- Er worden geen recepten of andere gegevens verwijderd.
-- InnoDB is nodig om samenhangende wijzigingen terug te draaien bij een fout.
ALTER TABLE recepten ENGINE = InnoDB;
ALTER TABLE recepten_ingredienten ENGINE = InnoDB;
ALTER TABLE recepten_stappen ENGINE = InnoDB;
ALTER TABLE recepten ADD COLUMN categorie VARCHAR(20) NOT NULL DEFAULT 'overig';
-- Bestaande recepten krijgen 'overig'. Kies daarna zelf de juiste categorie in het beheer.
-- De stapvolgorde gebruikt de bestaande ID: oudste stap eerst.
