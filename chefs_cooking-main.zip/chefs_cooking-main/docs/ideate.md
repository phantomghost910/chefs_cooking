# Fase 3: Ideate (Oplossingen bedenken)
## 1. Concepten
* **How-Might-We vraag:** [Vul in]
* **Concept 1:** [Korte beschrijving]
* **Concept 2:** [Korte beschrijving]
## 2. Conceptkeuze & Onderbouwing
04-prototype.md
05-test.md
*Welk concept gaan we bouwen en waarom sluit dit het beste aan bij de PvE
uit de Define fase?*
## 3. User Flow (Visueel)
![User Flow Diagram](./assets/user-flow.png)
