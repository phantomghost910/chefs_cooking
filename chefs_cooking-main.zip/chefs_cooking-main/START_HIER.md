# Chef’s Cooking – starten en gebruiken

## Wat is veranderd?

- De homepage haalt recepten uit jouw database. De vaste voorbeeldkaarten zijn vervangen door een PHP-loop.
- Recepten, ingrediënten en stappen kun je toevoegen, bekijken, bewerken en verwijderen.
- Foto’s kies je vanaf je computer. Zonder nieuwe foto blijft de bestaande foto behouden.
- `recept.php?id=...` toont de ingrediënten en genummerde bereidingsstappen.
- Met Vorige stap, Volgende stap en Toon alle stappen kies je hoe je kookt.
- Zoeken en filteren op categorie, minuten en prijs werken met de databasegegevens.
- De groene en lichte kleuren van je website zijn behouden.
- `database_connect.php` is niet veranderd.

## 1. Database eenmalig bijwerken

Maak eerst een back-up van je database via Exporteren in phpMyAdmin.

Open daarna jouw bestaande database en importeer `database_aanpassen.sql`.
Dit voegt alleen het nieuwe veld `categorie` toe en zorgt dat de drie tabellen InnoDB gebruiken. Met InnoDB kan PHP wijzigingen samen opslaan of bij een fout samen terugdraaien. Er wordt geen bestaande data verwijderd.

Voer het bestand één keer uit. Is het veld `categorie` al toegevoegd, voer de laatste ALTER-regel dan niet opnieuw uit. Bestaande recepten krijgen de categorie `overig`. Je kiest zelf de juiste categorie via Bewerken.

De andere kolomnamen volgen jouw screenshots, inclusief hoofdletters. Het bestand maakt geen nieuwe database of voorbeeldrecepten aan.

## 2. Project op de PHP-server zetten

Pak de ZIP uit en plaats de projectmap op de server waar jouw databaseverbinding werkt. Open `index.php` via een webadres, niet door het bestand te dubbelklikken.

Gebruik PHP 8.1 of nieuwer, met PDO MySQL en Fileinfo. De map `uploads` moet schrijfbaar zijn voor PHP. Neem ook `uploads/.htaccess` en `.user.ini` mee bij het uploaden; deze bestanden kunnen verborgen zijn in je bestandsbeheer.

`.user.ini` stelt de PHP-uploadlimiet in op 5 MB en de formulierlimiet op 8 MB. Dit werkt bij PHP-FPM/CGI, zoals veel Plesk-installaties. Controleer bij andere servers deze instellingen in php.ini. De webserver moet uploads van minimaal 8 MB toestaan.

`uploads/.htaccess` beschermt de uploadmap op Apache als AllowOverride is ingeschakeld. Gebruik je alleen Nginx, laat dan de serverbeheerder instellen dat bestanden in `uploads/` alleen als afbeeldingen worden geserveerd en nooit als PHP/scripts worden uitgevoerd.

Lokaal starten kan vanuit de projectmap met:

```bash
php -d upload_max_filesize=5M -d post_max_size=8M -S localhost:8000
```

Open dan `http://localhost:8000`. Dit werkt alleen als die computer ook jouw database kan bereiken. Als de verbinding alleen op de server van je klasgenoot werkt, plaats het project daar. `localhost` verwijst altijd naar de computer waarop PHP draait.

## 3. Een volledig recept toevoegen

1. Klik op Recepten beheren en vervolgens op + Toevoegen.
2. Vul naam, tijd in minuten, prijs, categorie en beschrijving in.
3. Kies eventueel een JPG-, PNG- of WebP-foto van maximaal 5 MB.
4. Klik op Opslaan.
5. Open Ingrediënten, klik op + Toevoegen en kies jouw recept in de keuzelijst.
6. Vul bijvoorbeeld `200 gram pasta` in. Sla op en herhaal voor de andere ingrediënten.
7. Open Bereidingsstappen en voeg de stappen één voor één toe. Kies steeds hetzelfde recept.
8. Vul per stap een korte titel, tijd en duidelijke uitleg in.
9. Klik op Bekijken om de receptpagina te openen.

De stappen staan op volgorde van hun bestaande ID: de eerst toegevoegde stap staat bovenaan. Voeg stappen daarom in de juiste volgorde toe. Je kunt bestaande stappen bewerken. Er is geen sleepfunctie om de volgorde te veranderen.

Bij een bereidingsstap staat ook het bestaande veld Prijs. Dat is in jouw database een heel getal. Laat 0 staan als je geen losse stapprijs gebruikt. De totale receptprijs mag wel centen bevatten; deze verschijnt op de website. Stapprijzen worden niet automatisch opgeteld.

## 4. Bewerken en verwijderen

- Bewerken opent een ingevuld formulier.
- Kies je geen nieuwe foto, dan blijft de oude staan.
- Kies je een nieuwe foto, dan vervangt die de oude.
- Vink Bestaande foto verwijderen aan om zonder foto verder te gaan. Een nieuwe upload heeft voorrang op dit vinkje.
- Bij een formulierfout blijven de tekstvelden ingevuld. Je moet een gekozen upload opnieuw selecteren; browsers mogen dat bestandsveld niet automatisch invullen.
- Annuleren gaat terug zonder de ingevoerde wijziging op te slaan.
- Verwijderen vraagt in de browser om bevestiging. Bij een recept verdwijnen ook de gekoppelde ingrediënten en stappen.
- Alleen ongebruikte, door deze versie geüploade foto’s worden opgeruimd. Bestaande afbeeldingen in `views/images` blijven staan.

## 5. Wat doen de bestanden?

- `database_connect.php`: jouw oorspronkelijke verbinding.
- `start.php`: laadt de verbinding en geeft een begrijpelijke melding als de database niet klaarstaat.
- `functies.php`: kleine herbruikbare functies voor veilige tekst, tijden en foto’s.
- `beheer.php`: de formulieren en INSERT, SELECT, UPDATE en DELETE.
- `table_call_on.php`: haalt de recepten op voor de homepage.
- `views/index.view.php`: toont de receptkaarten.
- `recept.php`: toont één recept, de ingrediënten en bereidingsstappen.
- `views/script/script.js`: het bestaande zoeken en filteren.
- `views/script/koken.js`: vorige/volgende stap en alle stappen tonen.

De drie onderdelen worden afzonderlijk opgeslagen: eerst het recept, daarna de ingrediënten en stappen. Je hoeft geen volledig recept in één lang formulier in te vullen.

## 6. Controle op jouw eigen server

Lees `TESTRESULTATEN.md` voor wat al gecontroleerd is. Loop op jouw eigen server deze lijst na:

- Voeg een recept toe zonder foto en bekijk het.
- Voeg een recept met foto toe en bekijk de homepage en detailpagina.
- Voeg ingrediënten en twee stappen toe; controleer de volgorde en kookknoppen.
- Bewerk een ingrediënt, een stap en de receptgegevens.
- Bewerk zonder nieuwe foto; de oude foto moet blijven staan.
- Vervang en verwijder de foto.
- Probeer een ongeldig bestand en een foto groter dan 5 MB.
- Test zoeken, alle filters, Filters wissen en Annuleren.
- Verwijder één ingrediënt of stap en controleer het juiste recept.
- Verwijder een testrecept en controleer dat andere recepten blijven bestaan.
- Ververs na Opslaan: er mag geen tweede recept bijkomen.

Het beheer heeft, net als je oorspronkelijke project, geen inlogsysteem. Gebruik het binnen je schoolomgeving of achter toegangsbeveiliging van je hosting.
