<?php
require __DIR__ . '/start.php';
$id = tekst($_GET, 'id');
$query = $conn->prepare('SELECT * FROM recepten WHERE ID = ?');
$query->execute([getal($id, 1, 2147483647) ? $id : 0]);
$recept = $query->fetch();
if (!$recept) {
    http_response_code(404); bovenkant('Niet gevonden');
    exit('<main class="beheer"><h2>Dit recept bestaat niet.</h2><a href="index.php">Terug naar recepten</a></main></body></html>');
}
$query = $conn->prepare('SELECT * FROM recepten_ingredienten WHERE recept_id = ? ORDER BY ID');
$query->execute([$id]); $ingredienten = $query->fetchAll();
$query = $conn->prepare('SELECT * FROM recepten_stappen WHERE recept_id = ? ORDER BY ID');
$query->execute([$id]); $stappen = $query->fetchAll();
bovenkant($recept['Naam']);
?>
<main class="beheer detail">
<h1><?= veilig($recept['Naam']) ?></h1>
<?= fotoHtml($recept['foto'], $recept['Naam']) ?>
<p><strong><?= minuten($recept['Tijd']) ?> minuten · €<?= number_format((float)$recept['Prijs'],2,',','.') ?></strong></p>
<p><?= nl2br(veilig($recept['info'])) ?></p>
<section><h2>Wat heb je nodig?</h2><ul><?php foreach ($ingredienten as $ingredient): ?><li><?= veilig($ingredient['Naam']) ?></li><?php endforeach; ?></ul>
<?php if (!$ingredienten): ?><p>Er zijn nog geen ingrediënten ingevuld.</p><?php endif; ?></section>
<section><h2>Zo maak je het</h2><p>Volg de stappen hieronder op volgorde.</p>
<?php if (!$stappen): ?><p>Er zijn nog geen bereidingsstappen ingevuld.</p><?php else: ?>
<div id="kookknoppen" hidden><button type="button" id="vorige">← Vorige stap</button><span id="stapstand" aria-live="polite"></span><button type="button" id="volgende">Volgende stap →</button><button type="button" id="alleStappen">Toon alle stappen</button></div>
<ol class="stappen">
<?php foreach ($stappen as $nummer => $stap): ?>
<li class="kookstap"><h3 tabindex="-1">Stap <?= $nummer + 1 ?>: <?= veilig($stap['Naam_title']) ?></h3>
<?php if ((int)$stap['Tijden'] > 0): ?><p class="staptijd"><?= (int)$stap['Tijden'] ?> minuten</p><?php endif; ?>
<p><?= nl2br(veilig($stap['beschrijving_stap'])) ?></p></li>
<?php endforeach; ?></ol>
<script src="views/script/koken.js"></script>
<?php endif; ?></section><a href="index.php">← Terug naar alle recepten</a>
</main></body></html>
