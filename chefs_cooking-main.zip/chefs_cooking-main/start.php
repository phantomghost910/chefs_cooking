<?php
require_once __DIR__ . '/functies.php';
// De oorspronkelijke verbinding blijft ongewijzigd. Toon bezoekers geen databasegeheimen.
ob_start();
require_once __DIR__ . '/database_connect.php';
ob_end_clean();
if (!isset($conn) || !($conn instanceof PDO)) {
    http_response_code(503);
    bovenkant('Geen verbinding');
    exit('<main class="beheer"><h2>Geen databaseverbinding</h2><p>Controleer of deze website draait op de server die toegang heeft tot jouw database.</p></main></body></html>');
}
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
$conn->exec('SET NAMES utf8mb4');
try {
    $conn->query('SELECT categorie FROM recepten LIMIT 0');
} catch (PDOException $e) {
    http_response_code(503);
    bovenkant('Database bijwerken');
    exit('<main class="beheer"><h2>Database bijwerken</h2><p>Voer eerst database_aanpassen.sql uit in phpMyAdmin. Lees START_HIER.md voor de uitleg.</p></main></body></html>');
}
