<?php
// Kleine functies die op meerdere pagina's worden gebruikt.
function veilig($tekst) {
    return htmlspecialchars((string) $tekst, ENT_QUOTES, 'UTF-8');
}
function tekst($bron, $naam) {
    return isset($bron[$naam]) && is_string($bron[$naam]) ? trim($bron[$naam]) : '';
}
function getal($waarde, $minimum, $maximum) {
    return filter_var($waarde, FILTER_VALIDATE_INT, ['options' => ['min_range' => $minimum, 'max_range' => $maximum]]) !== false;
}
function lengte($tekst) {
    return preg_match_all('/./us', $tekst);
}
function minuten($tijd) {
    $delen = explode(':', $tijd);
    return (int) $delen[0] * 60 + (int) ($delen[1] ?? 0);
}
function tijd($minuten) {
    return sprintf('%02d:%02d:00', intdiv((int) $minuten, 60), (int) $minuten % 60);
}
function fotoUrl($pad) {
    // Oude records mogen ook alleen een bestandsnaam bevatten.
    if (strpos($pad, '/') === false && strpos($pad, chr(92)) === false) $pad = 'views/images/' . $pad;
    // Alleen lokale afbeeldingen uit de twee afgesproken mappen tonen.
    if (!preg_match('~^(uploads|views/images)/[^/\\\\]+\.(jpg|jpeg|png|webp)$~i', $pad)) return '';
    if (!is_file(__DIR__ . '/' . $pad)) return '';
    $delen = explode('/', $pad);
    return implode('/', array_map('rawurlencode', $delen));
}
function fotoHtml($pad, $naam) {
    $url = fotoUrl($pad);
    if ($url === '') return '<div class="geen-foto">Geen foto beschikbaar</div>';
    return '<img src="' . veilig($url) . '" alt="' . veilig($naam) . '">';
}
function uploadFoto() {
    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE) return null;
    $bestand = $_FILES['foto'];
    if (!is_int($bestand['error']) || $bestand['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('De foto kon niet worden geüpload. Kies een foto van maximaal 5 MB.');
    }
    if ($bestand['size'] > 5 * 1024 * 1024 || $bestand['size'] < 1) {
        throw new RuntimeException('De foto moet tussen 1 byte en 5 MB zijn.');
    }
    $soorten = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $soort = (new finfo(FILEINFO_MIME_TYPE))->file($bestand['tmp_name']);
    if (!isset($soorten[$soort]) || !getimagesize($bestand['tmp_name'])) {
        throw new RuntimeException('Kies een echte JPG-, PNG- of WebP-afbeelding.');
    }
    $pad = 'uploads/' . bin2hex(random_bytes(16)) . '.' . $soorten[$soort];
    if (!move_uploaded_file($bestand['tmp_name'], __DIR__ . '/' . $pad)) {
        throw new RuntimeException('Opslaan van de foto lukt niet. Controleer of de map uploads schrijfbaar is.');
    }
    return $pad;
}
function verwijderLosseFoto($conn, $pad) {
    // Alleen eigen uploads opruimen, nooit bestaande projectfoto's.
    if (!preg_match('~^uploads/[a-f0-9]{32}\.(jpg|png|webp)$~', $pad)) return;
    $query = $conn->prepare('SELECT COUNT(*) FROM recepten WHERE foto = ?');
    $query->execute([$pad]);
    if ((int) $query->fetchColumn() === 0 && is_file(__DIR__ . '/' . $pad)) {
        if (!unlink(__DIR__ . '/' . $pad)) error_log('Een ongebruikte receptfoto kon niet worden opgeruimd.');
    }
}
function bovenkant($titel) {
    echo '<!DOCTYPE html><html lang="nl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . veilig($titel) . ' - Chef’s Cooking</title><link rel="stylesheet" href="views/css/style.css"></head><body><header><h1>Chef’s Cooking</h1></header><nav class="menu"><a href="index.php">Alle recepten</a><a href="beheer.php">Recepten beheren</a></nav>';
}
